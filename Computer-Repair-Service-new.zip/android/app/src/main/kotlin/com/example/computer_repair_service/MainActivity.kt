package com.example.computer_repair_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
